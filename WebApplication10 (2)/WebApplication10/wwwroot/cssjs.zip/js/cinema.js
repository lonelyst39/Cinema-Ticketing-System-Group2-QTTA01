(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Màn nhung: chỉ chạy một lần mỗi phiên
  var drape = $('.drape');
  if (drape) {
    var done = function () {
      document.documentElement.classList.remove('has-curtain');
      try { sessionStorage.setItem('curtain', '1'); } catch (e) {}
      drape.remove();
    };
    drape.lastElementChild.addEventListener('animationend', done);
    setTimeout(done, 2400);
  }

  // Menu mobile
  var tg = $('.nav-toggle'), nav = $('.nav');
  if (tg && nav) tg.addEventListener('click', function () {
    var open = nav.classList.toggle('open'); tg.setAttribute('aria-expanded', open);
  });

  // Toast tự tắt
  $$('.toast').forEach(function (t) {
    var close = function () { t.classList.add('leave'); setTimeout(function () { t.remove(); }, 320); };
    t.addEventListener('click', close); setTimeout(close, 6000);
  });

  // Hero carousel
  var hero = $('.hero');
  if (hero) {
    var slides = $$('.slide', hero), dots = $$('.dot', hero), cur = 0, timer, DUR = 6500;
    var go = function (n) {
      cur = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) { s.classList.toggle('on', i === cur); s.setAttribute('aria-hidden', i !== cur); });
      dots.forEach(function (d, i) {
        d.classList.remove('on'); void d.offsetWidth; d.classList.toggle('on', i === cur);
        d.style.setProperty('--dur', DUR + 'ms');
      });
    };
    var play = function () { clearInterval(timer); if (!reduce && slides.length > 1) timer = setInterval(function () { go(cur + 1); }, DUR); };
    dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); play(); }); });
    hero.addEventListener('mouseenter', function () { clearInterval(timer); });
    hero.addEventListener('mouseleave', play);
    go(0); play();
  }

  // Lọc phim: tab, thể loại, tìm kiếm
  var grid = $('#movies');
  if (grid) {
    var cards = $$('.mcard', grid), empty = $('#empty');
    var state = { status: 'now', genre: '*', q: '' };
    var norm = function (s) { return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd'); };
    var apply = function () {
      var n = 0;
      cards.forEach(function (c) {
        var ok = c.dataset.status === state.status &&
          (state.genre === '*' || c.dataset.genre === state.genre) &&
          (!state.q || norm(c.dataset.title).indexOf(state.q) > -1);
        c.classList.toggle('hide', !ok); if (ok) n++;
      });
      if (empty) empty.classList.toggle('hide', n > 0);
    };
    $$('.tab').forEach(function (t) { t.addEventListener('click', function () {
      $$('.tab').forEach(function (x) { x.classList.toggle('on', x === t); });
      state.status = t.dataset.status; apply(); }); });
    $$('.genre').forEach(function (c) { c.addEventListener('click', function () {
      $$('.genre').forEach(function (x) { x.classList.toggle('on', x === c); });
      state.genre = c.dataset.genre; apply(); }); });
    var si = $('#q'); if (si) si.addEventListener('input', function () { state.q = norm(si.value.trim()); apply(); });
    apply();
  }

  // Sao chép mã khuyến mãi
  $$('[data-copy]').forEach(function (b) { b.addEventListener('click', function () {
    var v = b.dataset.copy, old = b.textContent;
    var ok = function () { b.textContent = 'Đã chép'; setTimeout(function () { b.textContent = old; }, 1600); };
    if (navigator.clipboard) navigator.clipboard.writeText(v).then(ok, ok); else ok();
  }); });

  // Hiện/ẩn mật khẩu
  $$('[data-toggle-pw]').forEach(function (b) { b.addEventListener('click', function () {
    var i = b.parentElement.querySelector('input'); i.type = i.type === 'password' ? 'text' : 'password';
    b.firstElementChild.className = 'fa ' + (i.type === 'password' ? 'fa-eye' : 'fa-eye-slash');
  }); });
})();
